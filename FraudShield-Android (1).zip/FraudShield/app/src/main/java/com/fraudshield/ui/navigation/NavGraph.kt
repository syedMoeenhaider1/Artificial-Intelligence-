package com.fraudshield.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Dashboard : Screen("dashboard", "Dashboard", Icons.Default.Shield)
    object History : Screen("history", "History", Icons.Default.History)
    object Alerts : Screen("alerts", "Alerts", Icons.Default.Warning)
    object LinkScanner : Screen("link_scanner", "Link Scan", Icons.Default.Link)
    object Settings : Screen("settings", "Settings", Icons.Default.Settings)
}

val bottomNavItems = listOf(
    Screen.Dashboard,
    Screen.History,
    Screen.Alerts,
    Screen.LinkScanner,
    Screen.Settings
)
