package com.fraudshield.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fraudshield.ui.components.RiskBadge
import com.fraudshield.ui.components.SmsResultCard
import com.fraudshield.ui.components.riskColor
import com.fraudshield.ui.theme.*
import com.fraudshield.ui.viewmodel.DashboardStats
import com.fraudshield.ui.viewmodel.MainViewModel
import com.fraudshield.data.db.SmsResult
import com.fraudshield.data.db.RiskLevel

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    onNavigateToAlerts: () -> Unit,
    onNavigateToHistory: () -> Unit
) {
    val stats by viewModel.dashboardStats.collectAsState()
    val recent by viewModel.recentResults.collectAsState()
    val isScanning by viewModel.isScanningInbox.collectAsState()
    val progress by viewModel.inboxScanProgress.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { DashboardHeader(stats) }

        item { StatsRow(stats, onNavigateToAlerts, onNavigateToHistory) }

        if (stats.total == 0) {
            item { OnboardingCard(isScanning, progress, viewModel::scanExistingInbox) }
        } else {
            item {
                ScanInboxButton(isScanning, progress, viewModel::scanExistingInbox)
            }
        }

        if (recent.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Recent Scans", color = OnBackground, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    TextButton(onClick = onNavigateToHistory) {
                        Text("View All", color = Teal80, fontSize = 13.sp)
                    }
                }
            }
            items(recent) { result ->
                SmsResultCard(result = result, onDelete = { viewModel.deleteResult(result) })
            }
        }
    }
}

@Composable
private fun DashboardHeader(stats: DashboardStats) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "FraudShield",
                color = Teal80,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = (-0.5).sp
            )
            Text(
                text = "SMS Fraud Detector",
                color = OnSurfaceVariant,
                fontSize = 13.sp
            )
        }
        if (stats.unreadAlerts > 0) {
            BadgedBox(badge = {
                Badge(containerColor = DangerRed) {
                    Text("${stats.unreadAlerts}", color = OnBackground)
                }
            }) {
                Icon(Icons.Default.NotificationsActive, "Alerts", tint = DangerRed, modifier = Modifier.size(28.dp))
            }
        } else {
            Icon(Icons.Default.Shield, "Shield", tint = Teal80, modifier = Modifier.size(28.dp))
        }
    }
}

@Composable
private fun StatsRow(
    stats: DashboardStats,
    onNavigateToAlerts: () -> Unit,
    onNavigateToHistory: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StatCard(
            modifier = Modifier.weight(1f),
            value = "${stats.total}",
            label = "Scanned",
            color = Teal80,
            onClick = onNavigateToHistory
        )
        StatCard(
            modifier = Modifier.weight(1f),
            value = "${stats.dangerous}",
            label = "Dangerous",
            color = DangerRed,
            onClick = onNavigateToAlerts
        )
        StatCard(
            modifier = Modifier.weight(1f),
            value = "${stats.suspicious}",
            label = "Suspicious",
            color = WarningYellow,
            onClick = onNavigateToAlerts
        )
        StatCard(
            modifier = Modifier.weight(1f),
            value = "${stats.safe}",
            label = "Safe",
            color = SafeGreen,
            onClick = onNavigateToHistory
        )
    }
}

@Composable
private fun StatCard(
    modifier: Modifier = Modifier,
    value: String,
    label: String,
    color: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Surface),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, color = color, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text(label, color = OnSurfaceVariant, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun OnboardingCard(
    isScanning: Boolean,
    progress: Int,
    onScan: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Surface),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Teal80.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(Icons.Default.Shield, null, tint = Teal80, modifier = Modifier.size(48.dp))
            Text(
                "FraudShield is Active",
                color = OnBackground,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                "New incoming SMS will be automatically scanned. Tap below to scan your existing inbox.",
                color = OnSurfaceVariant,
                fontSize = 13.sp,
                lineHeight = 19.sp
            )
            ScanInboxButton(isScanning, progress, onScan)
        }
    }
}

@Composable
private fun ScanInboxButton(isScanning: Boolean, progress: Int, onScan: () -> Unit) {
    if (isScanning) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            LinearProgressIndicator(
                progress = { progress / 100f },
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)),
                color = Teal80,
                trackColor = SurfaceVariant
            )
            Text("Scanning inbox… $progress%", color = OnSurfaceVariant, fontSize = 12.sp)
        }
    } else {
        Button(
            onClick = onScan,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Teal80, contentColor = Background),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(Icons.Default.SearchOff, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Scan Existing Inbox", fontWeight = FontWeight.SemiBold)
        }
    }
}
