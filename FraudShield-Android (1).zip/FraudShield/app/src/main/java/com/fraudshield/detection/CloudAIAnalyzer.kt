package com.fraudshield.detection

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Unified Cloud AI Analyzer — secondary fraud detection signal.
 *
 * Supported providers:
 *  - GEMINI   → Google Gemini 2.0 Flash
 *  - OPENAI   → OpenAI GPT-4o-mini
 *  - CLAUDE   → Anthropic Claude 3 Haiku
 *
 * The AI verdict is ALWAYS secondary. FraudDetectionEngine makes the final decision.
 */
class CloudAIAnalyzer {

    enum class Provider(val displayName: String) {
        GEMINI("Gemini (Google)"),
        OPENAI("GPT-4o-mini (OpenAI)"),
        CLAUDE("Claude Haiku (Anthropic)")
    }

    data class AIVerdict(
        val provider: Provider,
        val verdict: String,       // SAFE | SUSPICIOUS | DANGEROUS
        val confidence: String,    // LOW | MEDIUM | HIGH
        val reasoning: String
    ) {
        fun formatted(): String =
            "[${provider.displayName}] $verdict (${confidence.lowercase()} confidence): $reasoning"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()
    private val tag = "CloudAIAnalyzer"

    suspend fun analyze(
        sender: String,
        message: String,
        primaryScore: Int,
        provider: Provider,
        apiKey: String
    ): AIVerdict? = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext null
        try {
            when (provider) {
                Provider.GEMINI -> callGemini(sender, message, primaryScore, apiKey)
                Provider.OPENAI -> callOpenAI(sender, message, primaryScore, apiKey)
                Provider.CLAUDE -> callClaude(sender, message, primaryScore, apiKey)
            }
        } catch (e: Exception) {
            Log.e(tag, "AI call failed (${provider.name}): ${e.message}")
            null
        }
    }

    // ── Gemini ─────────────────────────────────────────────────────────────────

    private fun callGemini(sender: String, message: String, score: Int, key: String): AIVerdict? {
        val body = buildGeminiBody(fraudPrompt(sender, message, score))
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$key")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()

        val resp = client.newCall(req).execute()
        if (!resp.isSuccessful) {
            Log.w(tag, "Gemini HTTP ${resp.code}")
            return null
        }
        val text = extractGeminiText(resp.body?.string() ?: return null) ?: return null
        return parseVerdictJson(text, Provider.GEMINI)
    }

    private fun buildGeminiBody(prompt: String): String {
        val obj = JsonObject().apply {
            add("contents", gson.toJsonTree(listOf(
                mapOf("parts" to listOf(mapOf("text" to prompt)))
            )))
            add("generationConfig", gson.toJsonTree(mapOf(
                "temperature" to 0.1,
                "maxOutputTokens" to 250
            )))
        }
        return gson.toJson(obj)
    }

    private fun extractGeminiText(json: String): String? = try {
        gson.fromJson(json, JsonObject::class.java)
            ?.getAsJsonArray("candidates")
            ?.get(0)?.asJsonObject
            ?.getAsJsonObject("content")
            ?.getAsJsonArray("parts")
            ?.get(0)?.asJsonObject
            ?.get("text")?.asString
    } catch (e: Exception) { null }

    // ── OpenAI ─────────────────────────────────────────────────────────────────

    private fun callOpenAI(sender: String, message: String, score: Int, key: String): AIVerdict? {
        val messages = JsonArray().apply {
            add(JsonObject().apply {
                addProperty("role", "system")
                addProperty("content",
                    "You are a fraud detection assistant for Pakistani SMS. " +
                    "Respond ONLY with valid JSON: {\"verdict\":\"SAFE|SUSPICIOUS|DANGEROUS\",\"confidence\":\"LOW|MEDIUM|HIGH\",\"reasoning\":\"one sentence\"}. No markdown."
                )
            })
            add(JsonObject().apply {
                addProperty("role", "user")
                addProperty("content", fraudPrompt(sender, message, score))
            })
        }

        val body = JsonObject().apply {
            addProperty("model", "gpt-4o-mini")
            add("messages", messages)
            addProperty("temperature", 0.1)
            addProperty("max_tokens", 200)
            addProperty("response_format", JsonObject().apply {
                addProperty("type", "json_object")
            }.toString().also {}) // hint JSON mode
        }
        // Rebuild properly
        val bodyObj = JsonObject().apply {
            addProperty("model", "gpt-4o-mini")
            add("messages", messages)
            addProperty("temperature", 0.1)
            addProperty("max_tokens", 200)
        }

        val req = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer $key")
            .addHeader("Content-Type", "application/json")
            .post(gson.toJson(bodyObj).toRequestBody("application/json".toMediaType()))
            .build()

        val resp = client.newCall(req).execute()
        if (!resp.isSuccessful) {
            Log.w(tag, "OpenAI HTTP ${resp.code}: ${resp.body?.string()?.take(200)}")
            return null
        }
        val text = extractOpenAIText(resp.body?.string() ?: return null) ?: return null
        return parseVerdictJson(text, Provider.OPENAI)
    }

    private fun extractOpenAIText(json: String): String? = try {
        gson.fromJson(json, JsonObject::class.java)
            ?.getAsJsonArray("choices")
            ?.get(0)?.asJsonObject
            ?.getAsJsonObject("message")
            ?.get("content")?.asString
    } catch (e: Exception) { null }

    // ── Anthropic Claude ────────────────────────────────────────────────────────

    private fun callClaude(sender: String, message: String, score: Int, key: String): AIVerdict? {
        val bodyObj = JsonObject().apply {
            addProperty("model", "claude-haiku-4-5")
            addProperty("max_tokens", 250)
            addProperty("system",
                "You are a fraud detection assistant for Pakistani SMS. " +
                "Respond ONLY with valid JSON: {\"verdict\":\"SAFE|SUSPICIOUS|DANGEROUS\",\"confidence\":\"LOW|MEDIUM|HIGH\",\"reasoning\":\"one sentence\"}. No markdown, no code fences."
            )
            add("messages", JsonArray().apply {
                add(JsonObject().apply {
                    addProperty("role", "user")
                    addProperty("content", fraudPrompt(sender, message, score))
                })
            })
        }

        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("x-api-key", key)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("Content-Type", "application/json")
            .post(gson.toJson(bodyObj).toRequestBody("application/json".toMediaType()))
            .build()

        val resp = client.newCall(req).execute()
        if (!resp.isSuccessful) {
            Log.w(tag, "Claude HTTP ${resp.code}: ${resp.body?.string()?.take(200)}")
            return null
        }
        val text = extractClaudeText(resp.body?.string() ?: return null) ?: return null
        return parseVerdictJson(text, Provider.CLAUDE)
    }

    private fun extractClaudeText(json: String): String? = try {
        gson.fromJson(json, JsonObject::class.java)
            ?.getAsJsonArray("content")
            ?.get(0)?.asJsonObject
            ?.get("text")?.asString
    } catch (e: Exception) { null }

    // ── Shared ─────────────────────────────────────────────────────────────────

    private fun fraudPrompt(sender: String, message: String, primaryScore: Int): String =
        """Analyze this SMS for fraud (Pakistani context).
Sender: "$sender"
Message: "$message"
Hybrid engine primary score: $primaryScore/100

Focus on: JazzCash, Easypaisa, HBL, UBL, Pakistani telecom operators, Urdu/Roman Urdu scam patterns.
Respond ONLY with JSON — no markdown, no extra text:
{"verdict":"SAFE|SUSPICIOUS|DANGEROUS","confidence":"LOW|MEDIUM|HIGH","reasoning":"one sentence in English"}"""

    private fun parseVerdictJson(raw: String, provider: Provider): AIVerdict? = try {
        val clean = raw.trim()
            .removePrefix("```json").removePrefix("```")
            .removeSuffix("```").trim()
        val obj = gson.fromJson(clean, JsonObject::class.java)
        AIVerdict(
            provider = provider,
            verdict = obj.get("verdict")?.asString?.uppercase() ?: "SUSPICIOUS",
            confidence = obj.get("confidence")?.asString?.uppercase() ?: "LOW",
            reasoning = obj.get("reasoning")?.asString ?: "Analysis complete."
        )
    } catch (e: Exception) {
        Log.w(tag, "JSON parse failed: ${e.message} | raw: ${raw.take(100)}")
        null
    }
}
