package com.fraudshield

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.work.Configuration
import com.fraudshield.data.repository.SmsRepository
import com.fraudshield.data.db.AppDatabase

class FraudShieldApp : Application(), Configuration.Provider {

    val database by lazy { AppDatabase.getInstance(this) }
    val repository by lazy { SmsRepository(database.smsResultDao()) }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        val nm = getSystemService(NotificationManager::class.java)

        val alertChannel = NotificationChannel(
            getString(R.string.notification_channel_id),
            getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = getString(R.string.notification_channel_desc)
            enableVibration(true)
            enableLights(true)
        }

        val monitorChannel = NotificationChannel(
            getString(R.string.monitor_channel_id),
            getString(R.string.monitor_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.monitor_channel_desc)
            setShowBadge(false)
        }

        nm.createNotificationChannels(listOf(alertChannel, monitorChannel))
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()
}
