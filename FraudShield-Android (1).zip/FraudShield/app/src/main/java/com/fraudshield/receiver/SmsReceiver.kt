package com.fraudshield.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import com.fraudshield.FraudShieldApp
import com.fraudshield.data.db.RiskLevel
import com.fraudshield.data.db.SmsResult
import com.fraudshield.detection.CloudAIAnalyzer
import com.fraudshield.detection.FraudDetectionEngine
import com.fraudshield.notification.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class SmsReceiver : BroadcastReceiver() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val tag = "SmsReceiver"

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isNullOrEmpty()) return

        messages.groupBy { it.originatingAddress ?: "Unknown" }.forEach { (sender, parts) ->
            val fullMessage = parts.joinToString("") { it.messageBody ?: "" }
            if (fullMessage.isNotBlank()) processSms(context, sender, fullMessage)
        }
    }

    private fun processSms(context: Context, sender: String, message: String) {
        val app = context.applicationContext as FraudShieldApp
        scope.launch {
            try {
                // 1. Primary: hybrid engine
                val engine = FraudDetectionEngine(context)
                val result = engine.analyze(
                    FraudDetectionEngine.AnalysisInput(sender = sender, message = message)
                )

                // 2. Secondary: cloud AI (only when suspicious/dangerous to save API quota)
                val aiVerdict = if (result.riskScore >= 31) {
                    runCloudAI(context, sender, message, result.riskScore)
                } else null

                // 3. Persist
                val smsResult = SmsResult(
                    sender = sender,
                    senderDisplayName = if (result.isTrustedSender)
                        com.fraudshield.detection.TrustedSenders.getTrustLabel(sender) ?: sender
                    else sender,
                    messageBody = message,
                    riskScore = result.riskScore,
                    riskLevel = RiskLevel.fromScore(result.riskScore),
                    detectionReasons = result.reasons.joinToString(" | "),
                    recommendation = result.recommendation,
                    isTrustedSender = result.isTrustedSender,
                    geminiVerdict = aiVerdict,
                    extractedUrls = result.extractedUrls.joinToString(",")
                )
                app.repository.insert(smsResult)

                // 4. Notify if risky
                val level = RiskLevel.fromScore(result.riskScore)
                if (level != RiskLevel.SAFE) {
                    NotificationHelper.showFraudAlert(
                        context = context,
                        sender = smsResult.senderDisplayName,
                        riskScore = result.riskScore,
                        riskLevel = level,
                        messagePreview = message
                    )
                }
                Log.d(tag, "Processed SMS — score=${result.riskScore}, ai=$aiVerdict")
            } catch (e: Exception) {
                Log.e(tag, "Error processing SMS", e)
            }
        }
    }

    private suspend fun runCloudAI(
        context: Context,
        sender: String,
        message: String,
        primaryScore: Int
    ): String? {
        return try {
            val prefs = context.getSharedPreferences("fraudshield_prefs", Context.MODE_PRIVATE)
            val providerName = prefs.getString("ai_provider", null) ?: return null
            val provider = CloudAIAnalyzer.Provider.valueOf(providerName)
            val apiKey = prefs.getString("ai_key_${providerName}", "") ?: return null
            if (apiKey.isBlank()) return null

            val verdict = CloudAIAnalyzer().analyze(
                sender = sender,
                message = message,
                primaryScore = primaryScore,
                provider = provider,
                apiKey = apiKey
            )
            verdict?.formatted()
        } catch (e: Exception) {
            Log.w(tag, "Cloud AI skipped: ${e.message}")
            null
        }
    }
}
