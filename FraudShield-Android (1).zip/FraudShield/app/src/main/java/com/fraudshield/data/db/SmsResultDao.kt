package com.fraudshield.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SmsResultDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(result: SmsResult): Long

    @Update
    suspend fun update(result: SmsResult)

    @Delete
    suspend fun delete(result: SmsResult)

    @Query("DELETE FROM sms_results WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM sms_results")
    suspend fun deleteAll()

    @Query("SELECT * FROM sms_results ORDER BY timestamp DESC")
    fun getAllResults(): Flow<List<SmsResult>>

    @Query("SELECT * FROM sms_results WHERE riskLevel = 'DANGEROUS' OR riskLevel = 'SUSPICIOUS' ORDER BY timestamp DESC")
    fun getAlerts(): Flow<List<SmsResult>>

    @Query("SELECT * FROM sms_results WHERE riskLevel = 'DANGEROUS' ORDER BY timestamp DESC")
    fun getDangerousResults(): Flow<List<SmsResult>>

    @Query("SELECT * FROM sms_results WHERE isRead = 0 AND (riskLevel = 'DANGEROUS' OR riskLevel = 'SUSPICIOUS')")
    fun getUnreadAlerts(): Flow<List<SmsResult>>

    @Query("SELECT COUNT(*) FROM sms_results")
    fun getTotalCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM sms_results WHERE riskLevel = 'DANGEROUS'")
    fun getDangerousCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM sms_results WHERE riskLevel = 'SUSPICIOUS'")
    fun getSuspiciousCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM sms_results WHERE riskLevel = 'SAFE'")
    fun getSafeCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM sms_results WHERE isRead = 0 AND (riskLevel = 'DANGEROUS' OR riskLevel = 'SUSPICIOUS')")
    fun getUnreadAlertCount(): Flow<Int>

    @Query("SELECT * FROM sms_results WHERE id = :id")
    suspend fun getById(id: Long): SmsResult?

    @Query("UPDATE sms_results SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: Long)

    @Query("UPDATE sms_results SET isRead = 1")
    suspend fun markAllAsRead()

    @Query("SELECT * FROM sms_results ORDER BY timestamp DESC LIMIT 5")
    fun getRecentResults(): Flow<List<SmsResult>>

    @Query("SELECT AVG(riskScore) FROM sms_results")
    fun getAverageRiskScore(): Flow<Double?>
}
