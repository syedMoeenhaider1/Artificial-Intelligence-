package com.fraudshield.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sms_results")
data class SmsResult(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val sender: String,
    val senderDisplayName: String,
    val messageBody: String,
    val riskScore: Int,
    val riskLevel: RiskLevel,
    val detectionReasons: String,
    val recommendation: String,
    val isTrustedSender: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val geminiVerdict: String? = null,
    val extractedUrls: String = ""
)

enum class RiskLevel {
    SAFE,
    SUSPICIOUS,
    DANGEROUS;

    companion object {
        fun fromScore(score: Int): RiskLevel = when {
            score <= 30 -> SAFE
            score <= 60 -> SUSPICIOUS
            else -> DANGEROUS
        }
    }
}
