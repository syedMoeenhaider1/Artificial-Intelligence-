package com.fraudshield.service

import android.app.Service
import android.content.ContentResolver
import android.content.Intent
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Telephony
import android.util.Log
import com.fraudshield.FraudShieldApp
import com.fraudshield.data.db.RiskLevel
import com.fraudshield.data.db.SmsResult
import com.fraudshield.detection.FraudDetectionEngine
import com.fraudshield.notification.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Foreground service that provides a persistent SMS monitoring layer.
 * The BroadcastReceiver (SmsReceiver) is the primary detection path.
 * This service adds ContentObserver as a fallback for devices that restrict broadcasts.
 */
class SmsMonitorService : Service() {

    private val job = SupervisorJob()
    private val scope = CoroutineScope(job + Dispatchers.IO)
    private val tag = "SmsMonitorService"

    private lateinit var handlerThread: HandlerThread
    private lateinit var handler: Handler
    private var smsObserver: SmsContentObserver? = null
    private var lastKnownSmsId: Long = -1L

    override fun onCreate() {
        super.onCreate()
        handlerThread = HandlerThread("SmsMonitorThread").also { it.start() }
        handler = Handler(handlerThread.looper)

        // Initialize lastKnownSmsId so we only process NEW messages
        lastKnownSmsId = getLatestSmsId()
        Log.d(tag, "Service started. Last known SMS id: $lastKnownSmsId")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1001, NotificationHelper.createMonitorNotification(this))
        registerSmsObserver()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        unregisterSmsObserver()
        handlerThread.quitSafely()
        job.cancel()
        super.onDestroy()
    }

    private fun registerSmsObserver() {
        smsObserver = SmsContentObserver(handler)
        contentResolver.registerContentObserver(
            Telephony.Sms.CONTENT_URI,
            true,
            smsObserver!!
        )
        Log.d(tag, "SMS ContentObserver registered")
    }

    private fun unregisterSmsObserver() {
        smsObserver?.let { contentResolver.unregisterContentObserver(it) }
        smsObserver = null
    }

    private fun getLatestSmsId(): Long {
        val cursor = contentResolver.query(
            Telephony.Sms.Inbox.CONTENT_URI,
            arrayOf(Telephony.Sms._ID),
            null, null,
            "${Telephony.Sms.DATE} DESC LIMIT 1"
        )
        return cursor?.use {
            if (it.moveToFirst()) it.getLong(0) else -1L
        } ?: -1L
    }

    private fun checkForNewSms() {
        scope.launch {
            try {
                val cursor = contentResolver.query(
                    Telephony.Sms.Inbox.CONTENT_URI,
                    arrayOf(Telephony.Sms._ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY),
                    "${Telephony.Sms._ID} > ?",
                    arrayOf(lastKnownSmsId.toString()),
                    "${Telephony.Sms.DATE} ASC"
                ) ?: return@launch

                cursor.use {
                    while (it.moveToNext()) {
                        val id = it.getLong(0)
                        val address = it.getString(1) ?: "Unknown"
                        val body = it.getString(2) ?: ""

                        if (id > lastKnownSmsId) {
                            lastKnownSmsId = id
                        }

                        if (body.isBlank()) continue

                        // Check if already processed by BroadcastReceiver
                        val app = applicationContext as FraudShieldApp
                        val engine = FraudDetectionEngine(applicationContext)
                        val result = engine.analyze(
                            FraudDetectionEngine.AnalysisInput(sender = address, message = body)
                        )

                        val smsResult = SmsResult(
                            sender = address,
                            senderDisplayName = if (result.isTrustedSender)
                                com.fraudshield.detection.TrustedSenders.getTrustLabel(address) ?: address
                            else address,
                            messageBody = body,
                            riskScore = result.riskScore,
                            riskLevel = RiskLevel.fromScore(result.riskScore),
                            detectionReasons = result.reasons.joinToString(" | "),
                            recommendation = result.recommendation,
                            isTrustedSender = result.isTrustedSender,
                            extractedUrls = result.extractedUrls.joinToString(",")
                        )

                        app.repository.insert(smsResult)

                        val level = RiskLevel.fromScore(result.riskScore)
                        if (level != RiskLevel.SAFE) {
                            NotificationHelper.showFraudAlert(
                                context = applicationContext,
                                sender = smsResult.senderDisplayName,
                                riskScore = result.riskScore,
                                riskLevel = level,
                                messagePreview = body
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(tag, "Error in SMS content observer check", e)
            }
        }
    }

    inner class SmsContentObserver(handler: Handler) : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean, uri: Uri?) {
            super.onChange(selfChange, uri)
            checkForNewSms()
        }
    }
}
