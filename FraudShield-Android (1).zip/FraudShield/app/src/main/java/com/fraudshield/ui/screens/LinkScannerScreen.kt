package com.fraudshield.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fraudshield.ui.components.RiskBadge
import com.fraudshield.ui.components.RiskScoreCircle
import com.fraudshield.ui.components.riskColor
import com.fraudshield.ui.theme.*
import com.fraudshield.ui.viewmodel.MainViewModel
import com.fraudshield.data.db.RiskLevel

@Composable
fun LinkScannerScreen(viewModel: MainViewModel) {
    var urlInput by remember { mutableStateOf("") }
    val isScanning by viewModel.isLinkScanning.collectAsState()
    val scanResult by viewModel.linkScanResult.collectAsState()
    val clipboard = LocalClipboardManager.current
    val focusRequester = remember { FocusRequester() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(Icons.Default.Link, null, tint = Teal80, modifier = Modifier.size(28.dp))
            Column {
                Text("Link Scanner", color = OnBackground, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Check if a URL is safe before clicking", color = OnSurfaceVariant, fontSize = 13.sp)
            }
        }

        // Input card
        Card(
            colors = CardDefaults.cardColors(containerColor = Surface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = urlInput,
                    onValueChange = {
                        urlInput = it
                        if (scanResult != null) viewModel.clearLinkScan()
                    },
                    modifier = Modifier.fillMaxWidth().focusRequester(focusRequester),
                    label = { Text("Enter URL to scan", color = OnSurfaceVariant) },
                    placeholder = { Text("https://example.com", color = OnSurfaceVariant.copy(alpha = 0.5f)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Uri,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(
                        onSearch = { if (urlInput.isNotBlank()) viewModel.scanUrl(urlInput.trim()) }
                    ),
                    trailingIcon = {
                        if (urlInput.isNotBlank()) {
                            IconButton(onClick = {
                                urlInput = ""
                                viewModel.clearLinkScan()
                            }) {
                                Icon(Icons.Default.Clear, "Clear", tint = OnSurfaceVariant)
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Teal80,
                        unfocusedBorderColor = CardBorder,
                        focusedTextColor = OnBackground,
                        unfocusedTextColor = OnBackground
                    ),
                    shape = RoundedCornerShape(10.dp)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Paste from clipboard
                    OutlinedButton(
                        onClick = {
                            val pasted = clipboard.getText()?.text ?: ""
                            if (pasted.isNotBlank()) {
                                urlInput = pasted
                                viewModel.clearLinkScan()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Teal80),
                        border = BorderStroke(1.dp, CardBorder),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.ContentPaste, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Paste", fontSize = 13.sp)
                    }

                    Button(
                        onClick = { if (urlInput.isNotBlank()) viewModel.scanUrl(urlInput.trim()) },
                        modifier = Modifier.weight(1f),
                        enabled = urlInput.isNotBlank() && !isScanning,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Teal80,
                            contentColor = Background,
                            disabledContainerColor = SurfaceVariant,
                            disabledContentColor = OnSurfaceVariant
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        if (isScanning) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = Teal80,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(Icons.Default.Search, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Scan", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        // Result
        AnimatedVisibility(visible = scanResult != null) {
            scanResult?.let { result ->
                val level = RiskLevel.fromScore(result.riskScore)
                val color = riskColor(level)

                Card(
                    colors = CardDefaults.cardColors(containerColor = Surface),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, color.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Score & level
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            RiskScoreCircle(score = result.riskScore, level = level, size = 72)
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                RiskBadge(level = level, score = result.riskScore)
                                Text(
                                    text = result.url.take(50) + if (result.url.length > 50) "…" else "",
                                    color = OnSurfaceVariant,
                                    fontSize = 12.sp,
                                    lineHeight = 17.sp
                                )
                            }
                        }

                        HorizontalDivider(color = Divider)

                        // Reasons
                        if (result.reasons.isNotEmpty()) {
                            Text("Detection Findings", color = OnSurfaceVariant, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp)
                            result.reasons.forEach { reason ->
                                Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("•", color = color, fontSize = 13.sp)
                                    Text(reason, color = OnSurface, fontSize = 13.sp, lineHeight = 18.sp)
                                }
                            }
                        }

                        // Recommendation
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(color.copy(alpha = 0.1f))
                                .padding(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.Info, null, tint = color, modifier = Modifier.size(16.dp))
                                Text(result.recommendation, color = OnSurface, fontSize = 13.sp, lineHeight = 18.sp)
                            }
                        }
                    }
                }
            }
        }

        // Safety tips
        SafetyTipsCard()
    }
}

@Composable
private fun SafetyTipsCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = Surface),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, CardBorder)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Lightbulb, null, tint = WarningYellow, modifier = Modifier.size(18.dp))
                Text("Safety Tips", color = OnBackground, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
            val tips = listOf(
                "Never click shortened URLs (bit.ly, tinyurl) from unknown senders",
                "Verify bank/fintech links by visiting the official website directly",
                "Real OTP messages never ask you to click a link",
                "Report scam messages to PTA: pta.gov.pk or 0800-55055"
            )
            tips.forEach { tip ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                    Text("•", color = Teal80, fontSize = 13.sp)
                    Text(tip, color = OnSurfaceVariant, fontSize = 13.sp, lineHeight = 18.sp)
                }
            }
        }
    }
}
