package com.fraudshield.data.repository

import com.fraudshield.data.db.SmsResult
import com.fraudshield.data.db.SmsResultDao
import kotlinx.coroutines.flow.Flow

class SmsRepository(private val dao: SmsResultDao) {

    fun getAllResults(): Flow<List<SmsResult>> = dao.getAllResults()
    fun getAlerts(): Flow<List<SmsResult>> = dao.getAlerts()
    fun getDangerousResults(): Flow<List<SmsResult>> = dao.getDangerousResults()
    fun getUnreadAlerts(): Flow<List<SmsResult>> = dao.getUnreadAlerts()
    fun getTotalCount(): Flow<Int> = dao.getTotalCount()
    fun getDangerousCount(): Flow<Int> = dao.getDangerousCount()
    fun getSuspiciousCount(): Flow<Int> = dao.getSuspiciousCount()
    fun getSafeCount(): Flow<Int> = dao.getSafeCount()
    fun getUnreadAlertCount(): Flow<Int> = dao.getUnreadAlertCount()
    fun getRecentResults(): Flow<List<SmsResult>> = dao.getRecentResults()
    fun getAverageRiskScore(): Flow<Double?> = dao.getAverageRiskScore()

    suspend fun insert(result: SmsResult): Long = dao.insert(result)
    suspend fun update(result: SmsResult) = dao.update(result)
    suspend fun delete(result: SmsResult) = dao.delete(result)
    suspend fun deleteById(id: Long) = dao.deleteById(id)
    suspend fun deleteAll() = dao.deleteAll()
    suspend fun getById(id: Long): SmsResult? = dao.getById(id)
    suspend fun markAsRead(id: Long) = dao.markAsRead(id)
    suspend fun markAllAsRead() = dao.markAllAsRead()
}
