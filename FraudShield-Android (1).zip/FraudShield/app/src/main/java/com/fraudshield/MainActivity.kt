package com.fraudshield

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.fraudshield.service.SmsMonitorService
import com.fraudshield.ui.FraudShieldApp
import com.fraudshield.ui.theme.FraudShieldTheme

class MainActivity : ComponentActivity() {

    private val permissionsRequired = buildList {
        add(Manifest.permission.RECEIVE_SMS)
        add(Manifest.permission.READ_SMS)
        add(Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val smsPerm = results[Manifest.permission.RECEIVE_SMS] == true ||
            results[Manifest.permission.READ_SMS] == true
        if (smsPerm) {
            startSmsMonitorService()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        val openAlerts = intent?.action == "com.fraudshield.ACTION_OPEN_ALERTS"

        setContent {
            FraudShieldTheme {
                FraudShieldApp(startOnAlerts = openAlerts)
            }
        }

        requestMissingPermissions()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    private fun requestMissingPermissions() {
        val missing = permissionsRequired.filter { perm ->
            ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        } else {
            startSmsMonitorService()
        }
    }

    private fun startSmsMonitorService() {
        val intent = Intent(this, SmsMonitorService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }
}
