package com.fraudshield.detection

import android.content.Context
import android.database.Cursor
import android.provider.ContactsContract
import com.fraudshield.data.db.RiskLevel
import kotlin.math.min

/**
 * Hybrid fraud detection engine.
 * Primary decision maker — Gemini AI is only a secondary signal.
 */
class FraudDetectionEngine(private val context: Context) {

    data class AnalysisInput(
        val sender: String,
        val message: String,
        val contactDisplayName: String? = null
    )

    fun analyze(input: AnalysisInput): DetectionResult {
        val sender = input.sender.trim()
        val message = input.message.trim()

        // 1. Check trusted sender whitelist first
        val isTrustedSender = TrustedSenders.isTrusted(sender)
        val trustLabel = TrustedSenders.getTrustLabel(sender)

        // 2. Extract URLs from message
        val urls = FraudPatterns.extractUrls(message)

        // 3. Score accumulation
        var score = 0
        val reasons = mutableListOf<String>()

        // 4. Trusted sender deduction
        if (isTrustedSender) {
            score -= 30
            trustLabel?.let { reasons.add("Verified sender: $it") }
        }

        // 5. Contact-known sender
        val contactName = input.contactDisplayName ?: lookupContact(sender)
        if (contactName != null) {
            score -= 10
            reasons.add("Sender in your contacts: $contactName")
        } else if (!isTrustedSender) {
            score += 20
            reasons.add("Unknown sender not in contacts")
        }

        // 6. Run all pattern groups
        score += scorePatterns(message, FraudPatterns.LOTTERY_PATTERNS, reasons)
        score += scorePatterns(message, FraudPatterns.INVESTMENT_PATTERNS, reasons)
        score += scorePatterns(message, FraudPatterns.PHISHING_PATTERNS, reasons)
        score += scorePatterns(message, FraudPatterns.OTP_PATTERNS, reasons)
        score += scorePatterns(message, FraudPatterns.URGENCY_PATTERNS, reasons)
        score += scorePatterns(message, FraudPatterns.MONEY_PATTERNS, reasons)
        score += scorePatterns(message, FraudPatterns.JOB_SCAM_PATTERNS, reasons)
        score += scorePatterns(message, FraudPatterns.GENERIC_SUSPICIOUS, reasons)

        // 7. URL analysis
        if (urls.isNotEmpty()) {
            if (FraudPatterns.containsShortenerUrl(urls)) {
                score += 30
                reasons.add("Contains URL shortener (hides real destination)")
            }

            val suspiciousDomains = urls.filter { url ->
                val domain = extractDomain(url)
                isSuspiciousDomain(domain)
            }
            if (suspiciousDomains.isNotEmpty()) {
                score += 40
                reasons.add("Suspicious/misspelled domain detected")
            } else if (urls.isNotEmpty()) {
                score += 10
                reasons.add("Contains external link (${urls.size} URL${if (urls.size > 1) "s" else ""})")
            }
        }

        // 8. Trusted sender with suspicious content — cap score reduction
        // If trusted sender sends money request or link, don't auto-safe it completely
        if (isTrustedSender && score > 20) {
            reasons.add("Trusted sender but message has suspicious elements — verify manually")
        }

        // 9. Clamp final score to 0–100
        val finalScore = score.coerceIn(0, 100)
        val riskLevel = RiskLevel.fromScore(finalScore)

        // 10. Generate recommendation
        val recommendation = buildRecommendation(finalScore, riskLevel, isTrustedSender, urls)

        return DetectionResult(
            riskScore = finalScore,
            reasons = reasons.distinct().filter { it.isNotBlank() },
            recommendation = recommendation,
            isTrustedSender = isTrustedSender,
            extractedUrls = urls
        )
    }

    private fun scorePatterns(
        message: String,
        patterns: List<FraudPatterns.Pattern>,
        reasons: MutableList<String>
    ): Int {
        var total = 0
        for (pattern in patterns) {
            if (pattern.regex.containsMatchIn(message)) {
                total += pattern.score
                if (pattern.score > 0) {
                    reasons.add(pattern.reason)
                }
            }
        }
        // Cap contribution per group to prevent extreme scores from one category
        return min(total, 60)
    }

    private fun lookupContact(phoneNumber: String): String? {
        return try {
            val uri = android.net.Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                android.net.Uri.encode(phoneNumber)
            )
            val cursor: Cursor? = context.contentResolver.query(
                uri,
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
                null, null, null
            )
            cursor?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun extractDomain(url: String): String {
        return try {
            val withoutScheme = url.replace(Regex("^https?://"), "")
            withoutScheme.substringBefore("/").substringBefore("?").lowercase()
        } catch (e: Exception) {
            url
        }
    }

    private fun isSuspiciousDomain(domain: String): Boolean {
        // Check for typosquatting of well-known brands
        val brandPatterns = listOf(
            "jazzcash", "easypaisa", "hblbank", "ubldigital",
            "meezanbank", "alliedbank", "daraz", "telenor", "jazz"
        )
        // Look for impersonation patterns like "hbl-bank.net", "jazzcash-pk.xyz"
        return brandPatterns.any { brand ->
            domain.contains(brand) && (
                domain.endsWith(".xyz") || domain.endsWith(".tk") ||
                domain.endsWith(".ml") || domain.endsWith(".ga") ||
                domain.endsWith(".cf") || domain.endsWith(".gq") ||
                domain.endsWith(".click") || domain.endsWith(".online") ||
                domain.contains("-") && domain.substringAfterLast(".").length <= 3
            )
        }
    }

    private fun buildRecommendation(
        score: Int,
        level: RiskLevel,
        trusted: Boolean,
        urls: List<String>
    ): String {
        return when (level) {
            RiskLevel.SAFE -> if (trusted) {
                "Message from a verified institution. No action required."
            } else {
                "Message appears safe. No suspicious patterns detected."
            }
            RiskLevel.SUSPICIOUS -> buildString {
                append("Exercise caution. Do not share personal information, OTPs, or banking credentials.")
                if (urls.isNotEmpty()) append(" Avoid clicking any links until you verify the sender.")
                if (!trusted) append(" This sender is not on the trusted list.")
            }
            RiskLevel.DANGEROUS -> buildString {
                append("HIGH RISK — Do not respond, click links, or share any information.")
                if (urls.isNotEmpty()) append(" The links in this message are potentially dangerous.")
                append(" Report to PTA at pta.gov.pk or call 0800-55055.")
                if (!trusted) append(" Block this sender immediately.")
            }
        }
    }
}
