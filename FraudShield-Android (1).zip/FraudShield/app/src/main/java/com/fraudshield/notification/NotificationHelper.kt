package com.fraudshield.notification

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.fraudshield.MainActivity
import com.fraudshield.R
import com.fraudshield.data.db.RiskLevel
import androidx.core.app.NotificationCompat
import kotlin.random.Random

object NotificationHelper {

    private const val MONITOR_NOTIFICATION_ID = 1001

    fun createMonitorNotification(context: Context): Notification {
        val openIntent = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(context, context.getString(R.string.monitor_channel_id))
            .setSmallIcon(R.drawable.ic_shield_small)
            .setContentTitle("FraudShield Active")
            .setContentText("Monitoring incoming SMS for fraud")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    fun showFraudAlert(
        context: Context,
        sender: String,
        riskScore: Int,
        riskLevel: RiskLevel,
        messagePreview: String
    ) {
        val (title, icon) = when (riskLevel) {
            RiskLevel.DANGEROUS -> "⚠️ Dangerous SMS from $sender" to R.drawable.ic_shield_alert
            RiskLevel.SUSPICIOUS -> "⚡ Suspicious SMS from $sender" to R.drawable.ic_shield_warning
            RiskLevel.SAFE -> return // Don't notify for safe messages
        }

        val openAlertsIntent = Intent(context, MainActivity::class.java).apply {
            action = "com.fraudshield.ACTION_OPEN_ALERTS"
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            Random.nextInt(),
            openAlertsIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val preview = if (messagePreview.length > 80) messagePreview.take(80) + "…" else messagePreview

        val notification = NotificationCompat.Builder(
            context,
            context.getString(R.string.notification_channel_id)
        )
            .setSmallIcon(icon)
            .setContentTitle(title)
            .setContentText("Risk Score: $riskScore/100 — $preview")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .setBigContentTitle(title)
                    .bigText("Risk Score: $riskScore/100\n\n$preview")
            )
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setPriority(
                if (riskLevel == RiskLevel.DANGEROUS) NotificationCompat.PRIORITY_HIGH
                else NotificationCompat.PRIORITY_DEFAULT
            )
            .setVibrate(
                if (riskLevel == RiskLevel.DANGEROUS) longArrayOf(0, 300, 200, 300)
                else longArrayOf(0, 200)
            )
            .build()

        val nm = context.getSystemService(NotificationManager::class.java)
        nm.notify(Random.nextInt(10000, 99999), notification)
    }
}
