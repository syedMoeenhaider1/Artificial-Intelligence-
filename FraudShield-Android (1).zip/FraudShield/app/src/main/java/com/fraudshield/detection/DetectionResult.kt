package com.fraudshield.detection

data class DetectionResult(
    val riskScore: Int,
    val reasons: List<String>,
    val recommendation: String,
    val isTrustedSender: Boolean,
    val extractedUrls: List<String> = emptyList(),
    val geminiVerdict: String? = null
) {
    companion object {
        fun safe(reason: String = "Message appears legitimate"): DetectionResult =
            DetectionResult(
                riskScore = 0,
                reasons = listOf(reason),
                recommendation = "No action required. This message is safe.",
                isTrustedSender = true
            )
    }
}
