package com.fraudshield.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fraudshield.data.db.RiskLevel
import com.fraudshield.ui.components.SmsResultCard
import com.fraudshield.ui.theme.*
import com.fraudshield.ui.viewmodel.MainViewModel

@Composable
fun AlertsScreen(viewModel: MainViewModel) {
    val alerts by viewModel.alerts.collectAsState()
    val stats by viewModel.dashboardStats.collectAsState()

    val dangerous = alerts.filter { it.riskLevel == RiskLevel.DANGEROUS }
    val suspicious = alerts.filter { it.riskLevel == RiskLevel.SUSPICIOUS }

    LaunchedEffect(Unit) {
        viewModel.markAllAsRead()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Fraud Alerts", color = OnBackground, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "${alerts.size} alert${if (alerts.size != 1) "s" else ""} detected",
                        color = OnSurfaceVariant,
                        fontSize = 13.sp
                    )
                }
                Icon(Icons.Default.Warning, null, tint = DangerRed, modifier = Modifier.size(28.dp))
            }
        }

        // Summary banner
        if (dangerous.isNotEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DangerContainer)
                        .border(1.dp, DangerRed.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Default.GppBad, null, tint = DangerRed, modifier = Modifier.size(32.dp))
                        Column {
                            Text(
                                "${dangerous.size} Dangerous Message${if (dangerous.size != 1) "s" else ""} Found",
                                color = DangerRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                "Do not click links or share personal info from these messages.",
                                color = OnSurface,
                                fontSize = 12.sp,
                                lineHeight = 17.sp
                            )
                        }
                    }
                }
            }
        }

        if (alerts.isEmpty()) {
            item {
                Box(
                    Modifier.fillMaxWidth().padding(vertical = 48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.GppGood, null, tint = SafeGreen, modifier = Modifier.size(56.dp))
                        Text("No Alerts", color = OnBackground, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Text("All scanned messages appear safe.", color = OnSurfaceVariant, fontSize = 13.sp)
                    }
                }
            }
        }

        if (dangerous.isNotEmpty()) {
            item {
                SectionLabel("Dangerous", DangerRed, dangerous.size)
            }
            items(dangerous, key = { it.id }) { result ->
                SmsResultCard(result = result, onDelete = { viewModel.deleteResult(result) })
            }
        }

        if (suspicious.isNotEmpty()) {
            item {
                SectionLabel("Suspicious", WarningYellow, suspicious.size)
            }
            items(suspicious, key = { it.id }) { result ->
                SmsResultCard(result = result, onDelete = { viewModel.deleteResult(result) })
            }
        }

        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun SectionLabel(
    label: String,
    color: androidx.compose.ui.graphics.Color,
    count: Int
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(Modifier.size(3.dp, 18.dp).clip(RoundedCornerShape(2.dp)).background(color))
        Text(label, color = color, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Text("($count)", color = color.copy(alpha = 0.6f), fontSize = 13.sp)
    }
}
