package com.fraudshield.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fraudshield.data.db.RiskLevel
import com.fraudshield.ui.components.SmsResultCard
import com.fraudshield.ui.theme.*
import com.fraudshield.ui.viewmodel.MainViewModel

@Composable
fun HistoryScreen(viewModel: MainViewModel) {
    val allResults by viewModel.allResults.collectAsState()
    var filterLevel by remember { mutableStateOf<RiskLevel?>(null) }
    var showDeleteAllDialog by remember { mutableStateOf(false) }

    val filtered = if (filterLevel == null) allResults else allResults.filter { it.riskLevel == filterLevel }

    if (showDeleteAllDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAllDialog = false },
            containerColor = Surface,
            title = { Text("Clear All History", color = OnBackground) },
            text = { Text("Delete all ${allResults.size} scan records? This cannot be undone.", color = OnSurfaceVariant) },
            confirmButton = {
                TextButton(
                    onClick = { viewModel.deleteAll(); showDeleteAllDialog = false },
                    colors = ButtonDefaults.textButtonColors(contentColor = DangerRed)
                ) { Text("Delete All") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAllDialog = false }) { Text("Cancel") }
            }
        )
    }

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        // Top bar
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Scan History", color = OnBackground, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("${allResults.size} total messages scanned", color = OnSurfaceVariant, fontSize = 13.sp)
            }
            if (allResults.isNotEmpty()) {
                IconButton(onClick = { showDeleteAllDialog = true }) {
                    Icon(Icons.Default.DeleteSweep, "Clear all", tint = OnSurfaceVariant)
                }
            }
        }

        // Filter chips
        Row(
            modifier = Modifier.padding(horizontal = 16.dp).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChipItem("All", filterLevel == null, DangerRed) { filterLevel = null }
            FilterChipItem("Dangerous", filterLevel == RiskLevel.DANGEROUS, DangerRed) {
                filterLevel = if (filterLevel == RiskLevel.DANGEROUS) null else RiskLevel.DANGEROUS
            }
            FilterChipItem("Suspicious", filterLevel == RiskLevel.SUSPICIOUS, WarningYellow) {
                filterLevel = if (filterLevel == RiskLevel.SUSPICIOUS) null else RiskLevel.SUSPICIOUS
            }
            FilterChipItem("Safe", filterLevel == RiskLevel.SAFE, SafeGreen) {
                filterLevel = if (filterLevel == RiskLevel.SAFE) null else RiskLevel.SAFE
            }
        }

        Spacer(Modifier.height(12.dp))

        if (filtered.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Inbox, null, tint = OnSurfaceVariant, modifier = Modifier.size(48.dp))
                    Text("No scan results yet", color = OnSurfaceVariant, fontSize = 15.sp)
                    Text("Incoming SMS will be auto-scanned", color = OnSurfaceVariant, fontSize = 13.sp)
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filtered, key = { it.id }) { result ->
                    SmsResultCard(
                        result = result,
                        onDelete = { viewModel.deleteResult(result) }
                    )
                }
                item { Spacer(Modifier.height(8.dp)) }
            }
        }
    }
}

@Composable
private fun FilterChipItem(
    label: String,
    selected: Boolean,
    color: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, fontSize = 13.sp) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = color.copy(alpha = 0.2f),
            selectedLabelColor = color,
            containerColor = SurfaceVariant,
            labelColor = OnSurfaceVariant
        ),
        border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = selected,
            selectedBorderColor = color.copy(alpha = 0.5f),
            borderColor = CardBorder
        )
    )
}
