package com.fraudshield.ui.theme

import androidx.compose.ui.graphics.Color

val Teal80 = Color(0xFF00D4AA)
val Teal60 = Color(0xFF00A884)
val Teal40 = Color(0xFF007A62)

val Background = Color(0xFF0D1117)
val Surface = Color(0xFF161B22)
val SurfaceVariant = Color(0xFF21262D)
val OnBackground = Color(0xFFF0F6FC)
val OnSurface = Color(0xFFE6EDF3)
val OnSurfaceVariant = Color(0xFF8B949E)

val SafeGreen = Color(0xFF00C853)
val SafeGreenContainer = Color(0xFF00361A)
val WarningYellow = Color(0xFFFFB300)
val WarningContainer = Color(0xFF3D2E00)
val DangerRed = Color(0xFFF44336)
val DangerContainer = Color(0xFF3D0A06)

val CardBorder = Color(0xFF30363D)
val Divider = Color(0xFF21262D)
