package com.fraudshield.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.fraudshield.ui.navigation.Screen
import com.fraudshield.ui.navigation.bottomNavItems
import com.fraudshield.ui.screens.*
import com.fraudshield.ui.theme.*
import com.fraudshield.ui.viewmodel.MainViewModel

@Composable
fun FraudShieldApp(startOnAlerts: Boolean = false) {
    val navController = rememberNavController()
    val viewModel: MainViewModel = viewModel()
    val unreadAlerts by viewModel.dashboardStats.collectAsState()

    LaunchedEffect(startOnAlerts) {
        if (startOnAlerts) {
            navController.navigate(Screen.Alerts.route) {
                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        }
    }

    Scaffold(
        containerColor = Background,
        bottomBar = {
            NavigationBar(containerColor = Surface, tonalElevation = 0.dp) {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDest = navBackStackEntry?.destination

                bottomNavItems.forEach { screen ->
                    val selected = currentDest?.hierarchy?.any { it.route == screen.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = {
                            if (screen == Screen.Alerts && unreadAlerts.unreadAlerts > 0) {
                                BadgedBox(badge = {
                                    Badge { Text("${unreadAlerts.unreadAlerts}") }
                                }) {
                                    Icon(screen.icon, contentDescription = screen.label)
                                }
                            } else {
                                Icon(screen.icon, contentDescription = screen.label)
                            }
                        },
                        label = { Text(screen.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Teal80,
                            selectedTextColor = Teal80,
                            unselectedIconColor = OnSurfaceVariant,
                            unselectedTextColor = OnSurfaceVariant,
                            indicatorColor = Teal80.copy(alpha = 0.15f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Dashboard.route) {
                DashboardScreen(viewModel = viewModel, onNavigateToAlerts = {
                    navController.navigate(Screen.Alerts.route)
                }, onNavigateToHistory = {
                    navController.navigate(Screen.History.route)
                })
            }
            composable(Screen.History.route) {
                HistoryScreen(viewModel = viewModel)
            }
            composable(Screen.Alerts.route) {
                AlertsScreen(viewModel = viewModel)
            }
            composable(Screen.LinkScanner.route) {
                LinkScannerScreen(viewModel = viewModel)
            }
            composable(Screen.Settings.route) {
                SettingsScreen(viewModel = viewModel)
            }
        }
    }
}
