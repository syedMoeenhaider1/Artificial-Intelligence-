package com.fraudshield.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fraudshield.detection.CloudAIAnalyzer
import com.fraudshield.ui.theme.*
import com.fraudshield.ui.viewmodel.MainViewModel

@Composable
fun SettingsScreen(viewModel: MainViewModel) {
    var monitoringEnabled by remember { mutableStateOf(viewModel.getMonitoringEnabled()) }
    val uriHandler = LocalUriHandler.current

    // AI Provider
    var selectedProvider by remember {
        mutableStateOf(viewModel.getSelectedAIProvider())
    }
    var providerDropdownOpen by remember { mutableStateOf(false) }

    // Per-provider keys
    var geminiKey by remember { mutableStateOf(viewModel.getAIKey(CloudAIAnalyzer.Provider.GEMINI)) }
    var openaiKey by remember { mutableStateOf(viewModel.getAIKey(CloudAIAnalyzer.Provider.OPENAI)) }
    var claudeKey by remember { mutableStateOf(viewModel.getAIKey(CloudAIAnalyzer.Provider.CLAUDE)) }

    var showGeminiKey by remember { mutableStateOf(false) }
    var showOpenAIKey by remember { mutableStateOf(false) }
    var showClaudeKey by remember { mutableStateOf(false) }
    var keySaved by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Settings", color = OnBackground, fontSize = 22.sp, fontWeight = FontWeight.Bold)

        // ── Monitoring ────────────────────────────────────────────────────────
        SettingsSection(title = "Detection") {
            SettingRow(
                icon = Icons.Default.Shield,
                iconTint = Teal80,
                title = "Real-time SMS Monitoring",
                subtitle = "Automatically scan incoming messages",
                trailing = {
                    Switch(
                        checked = monitoringEnabled,
                        onCheckedChange = {
                            monitoringEnabled = it
                            viewModel.setMonitoringEnabled(it)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Background,
                            checkedTrackColor = Teal80
                        )
                    )
                }
            )
        }

        // ── Cloud AI ──────────────────────────────────────────────────────────
        SettingsSection(title = "Cloud AI — Secondary Analysis (Optional)") {
            Column(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Info banner
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Teal80.copy(alpha = 0.08f))
                        .padding(12.dp)
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                        Icon(Icons.Default.AutoAwesome, null, tint = Teal80, modifier = Modifier.size(16.dp))
                        Text(
                            "AI provides a supporting verdict. The hybrid engine always makes the final decision.",
                            color = OnSurfaceVariant,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    }
                }

                // Provider selector
                Text("AI Provider", color = OnBackground, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)

                Box {
                    OutlinedButton(
                        onClick = { providerDropdownOpen = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = OnBackground),
                        border = BorderStroke(1.dp, if (selectedProvider != null) Teal80 else CardBorder),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            if (selectedProvider != null) Icons.Default.AutoAwesome else Icons.Default.CloudOff,
                            null,
                            tint = if (selectedProvider != null) Teal80 else OnSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            selectedProvider?.displayName ?: "Disabled — No AI",
                            modifier = Modifier.weight(1f),
                            color = if (selectedProvider != null) OnBackground else OnSurfaceVariant,
                            fontSize = 14.sp
                        )
                        Icon(Icons.Default.ExpandMore, null, tint = OnSurfaceVariant)
                    }

                    DropdownMenu(
                        expanded = providerDropdownOpen,
                        onDismissRequest = { providerDropdownOpen = false },
                        modifier = Modifier.background(SurfaceVariant)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Disabled — No AI", color = OnSurfaceVariant) },
                            leadingIcon = { Icon(Icons.Default.CloudOff, null, tint = OnSurfaceVariant) },
                            onClick = {
                                selectedProvider = null
                                viewModel.setSelectedAIProvider(null)
                                providerDropdownOpen = false
                                keySaved = false
                            }
                        )
                        HorizontalDivider(color = Divider)
                        CloudAIAnalyzer.Provider.entries.forEach { provider ->
                            val (icon, tint) = providerMeta(provider)
                            DropdownMenuItem(
                                text = { Text(provider.displayName, color = OnBackground) },
                                leadingIcon = { Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp)) },
                                onClick = {
                                    selectedProvider = provider
                                    viewModel.setSelectedAIProvider(provider)
                                    providerDropdownOpen = false
                                    keySaved = false
                                }
                            )
                        }
                    }
                }

                // Per-provider API key input
                AnimatedVisibility(visible = selectedProvider != null) {
                    selectedProvider?.let { provider ->
                        val (currentKey, setKey, showKey, toggleShow, helpUrl, helpText) = when (provider) {
                            CloudAIAnalyzer.Provider.GEMINI -> ApiKeyState(
                                key = geminiKey, setKey = { geminiKey = it },
                                showKey = showGeminiKey, toggleShow = { showGeminiKey = !showGeminiKey },
                                helpUrl = "https://aistudio.google.com/apikey",
                                helpText = "Get free key at aistudio.google.com"
                            )
                            CloudAIAnalyzer.Provider.OPENAI -> ApiKeyState(
                                key = openaiKey, setKey = { openaiKey = it },
                                showKey = showOpenAIKey, toggleShow = { showOpenAIKey = !showOpenAIKey },
                                helpUrl = "https://platform.openai.com/api-keys",
                                helpText = "Get key at platform.openai.com"
                            )
                            CloudAIAnalyzer.Provider.CLAUDE -> ApiKeyState(
                                key = claudeKey, setKey = { claudeKey = it },
                                showKey = showClaudeKey, toggleShow = { showClaudeKey = !showClaudeKey },
                                helpUrl = "https://console.anthropic.com/settings/keys",
                                helpText = "Get key at console.anthropic.com"
                            )
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = currentKey,
                                onValueChange = { setKey(it); keySaved = false },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("${provider.displayName} API Key", color = OnSurfaceVariant) },
                                placeholder = { Text("Paste your API key here…", color = OnSurfaceVariant.copy(alpha = 0.4f)) },
                                singleLine = true,
                                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                trailingIcon = {
                                    IconButton(onClick = toggleShow) {
                                        Icon(
                                            if (showKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            null, tint = OnSurfaceVariant
                                        )
                                    }
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Teal80,
                                    unfocusedBorderColor = CardBorder,
                                    focusedTextColor = OnBackground,
                                    unfocusedTextColor = OnBackground
                                ),
                                shape = RoundedCornerShape(10.dp)
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = {
                                        viewModel.saveAIKey(provider, currentKey)
                                        keySaved = true
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Teal80, contentColor = Background
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Save, null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Save Key", fontWeight = FontWeight.SemiBold)
                                }

                                if (currentKey.isNotBlank()) {
                                    OutlinedButton(
                                        onClick = {
                                            setKey("")
                                            viewModel.saveAIKey(provider, "")
                                            keySaved = false
                                        },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed),
                                        border = BorderStroke(1.dp, DangerRed.copy(alpha = 0.4f)),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("Remove")
                                    }
                                }
                            }

                            if (keySaved) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.CheckCircle, null, tint = SafeGreen, modifier = Modifier.size(16.dp))
                                    Text("Key saved", color = SafeGreen, fontSize = 12.sp)
                                }
                            }

                            TextButton(
                                onClick = { uriHandler.openUri(helpUrl) },
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Icon(Icons.Default.OpenInNew, null, modifier = Modifier.size(13.dp), tint = Teal80)
                                Spacer(Modifier.width(4.dp))
                                Text("$helpText →", color = Teal80, fontSize = 12.sp)
                            }
                        }
                    }
                }

                // Provider comparison
                AnimatedVisibility(visible = selectedProvider == null) {
                    ProviderComparisonCard()
                }
            }
        }

        // ── Trusted Senders ───────────────────────────────────────────────────
        SettingsSection(title = "Trusted Sender Whitelist") {
            Column(
                Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "Messages from these senders are not auto-flagged as fraud:",
                    color = OnSurfaceVariant,
                    fontSize = 12.sp
                )
                val trusted = listOf(
                    "JazzCash", "Easypaisa", "Jazz", "Zong", "Telenor", "Ufone",
                    "HBL", "UBL", "Meezan Bank", "Allied Bank", "MCB", "NBP",
                    "NayaPay", "SadaPay", "FBR", "NADRA", "PTA", "SBP",
                    "Daraz", "Careem", "1Link / Raast"
                )
                TrustedChipsRow(trusted)
            }
        }

        // ── About ─────────────────────────────────────────────────────────────
        SettingsSection(title = "About") {
            SettingRow(
                icon = Icons.Default.Shield,
                iconTint = Teal80,
                title = "FraudShield",
                subtitle = "Version 1.1.0 — SMS Fraud Detector for Pakistan",
                trailing = {}
            )
            SettingRow(
                icon = Icons.Default.Policy,
                iconTint = OnSurfaceVariant,
                title = "Report Fraud",
                subtitle = "PTA: pta.gov.pk | Helpline: 0800-55055",
                trailing = {}
            )
        }
    }
}

// ── Data class to reduce parameter list ──────────────────────────────────────

private data class ApiKeyState(
    val key: String,
    val setKey: (String) -> Unit,
    val showKey: Boolean,
    val toggleShow: () -> Unit,
    val helpUrl: String,
    val helpText: String
)

private operator fun ApiKeyState.component1() = key
private operator fun ApiKeyState.component2() = setKey
private operator fun ApiKeyState.component3() = showKey
private operator fun ApiKeyState.component4() = toggleShow
private operator fun ApiKeyState.component5() = helpUrl
private operator fun ApiKeyState.component6() = helpText

// ── Provider icons ────────────────────────────────────────────────────────────

@Composable
private fun providerMeta(provider: CloudAIAnalyzer.Provider): Pair<androidx.compose.ui.graphics.vector.ImageVector, androidx.compose.ui.graphics.Color> =
    when (provider) {
        CloudAIAnalyzer.Provider.GEMINI -> Icons.Default.AutoAwesome to Teal80
        CloudAIAnalyzer.Provider.OPENAI -> Icons.Default.Psychology to SafeGreen
        CloudAIAnalyzer.Provider.CLAUDE -> Icons.Default.Biotech to WarningYellow
    }

// ── Provider comparison ───────────────────────────────────────────────────────

@Composable
private fun ProviderComparisonCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceVariant),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, CardBorder)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Available AI Providers", color = OnBackground, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)

            val providers = listOf(
                Triple(Icons.Default.AutoAwesome, Teal80,
                    "Gemini (Google)" to "Free tier. aistudio.google.com"),
                Triple(Icons.Default.Psychology, SafeGreen,
                    "GPT-4o-mini (OpenAI)" to "Fast & accurate. platform.openai.com"),
                Triple(Icons.Default.Biotech, WarningYellow,
                    "Claude Haiku (Anthropic)" to "Detailed reasoning. console.anthropic.com")
            )

            providers.forEach { (icon, tint, info) ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp))
                    Column {
                        Text(info.first, color = OnBackground, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Text(info.second, color = OnSurfaceVariant, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

// ── Shared composables ────────────────────────────────────────────────────────

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
        Text(
            title.uppercase(),
            color = Teal80,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 6.dp, start = 2.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = Surface),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Column(content = content)
        }
    }
}

@Composable
private fun SettingRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: androidx.compose.ui.graphics.Color,
    title: String,
    subtitle: String,
    trailing: @Composable () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(iconTint.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = iconTint, modifier = Modifier.size(20.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = OnBackground, fontWeight = FontWeight.Medium, fontSize = 14.sp)
            if (subtitle.isNotBlank()) {
                Text(subtitle, color = OnSurfaceVariant, fontSize = 12.sp, lineHeight = 17.sp)
            }
        }
        trailing()
    }
}

@Composable
private fun TrustedChipsRow(items: List<String>) {
    val rows = items.chunked(4)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { item ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Teal80.copy(alpha = 0.1f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(item, color = Teal80, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}
