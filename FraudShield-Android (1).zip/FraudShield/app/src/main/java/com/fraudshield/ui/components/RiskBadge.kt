package com.fraudshield.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fraudshield.data.db.RiskLevel
import com.fraudshield.ui.theme.*

@Composable
fun RiskBadge(level: RiskLevel, score: Int, modifier: Modifier = Modifier) {
    val (bg, fg, label) = when (level) {
        RiskLevel.SAFE -> Triple(SafeGreenContainer, SafeGreen, "SAFE")
        RiskLevel.SUSPICIOUS -> Triple(WarningContainer, WarningYellow, "SUSPICIOUS")
        RiskLevel.DANGEROUS -> Triple(DangerContainer, DangerRed, "DANGEROUS")
    }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = label,
            color = fg,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.8.sp
        )
        Text(
            text = "$score",
            color = fg.copy(alpha = 0.85f),
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun RiskScoreCircle(score: Int, level: RiskLevel, size: Int = 72) {
    val color = riskColor(level)
    Box(
        modifier = Modifier
            .size(size.dp)
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "$score",
                color = color,
                fontSize = (size / 3).sp,
                fontWeight = FontWeight.Black,
                lineHeight = (size / 3).sp
            )
            Text(
                text = "/100",
                color = color.copy(alpha = 0.6f),
                fontSize = (size / 6).sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

fun riskColor(level: RiskLevel): Color = when (level) {
    RiskLevel.SAFE -> SafeGreen
    RiskLevel.SUSPICIOUS -> WarningYellow
    RiskLevel.DANGEROUS -> DangerRed
}

fun riskEmoji(level: RiskLevel): String = when (level) {
    RiskLevel.SAFE -> "✓"
    RiskLevel.SUSPICIOUS -> "!"
    RiskLevel.DANGEROUS -> "✕"
}
