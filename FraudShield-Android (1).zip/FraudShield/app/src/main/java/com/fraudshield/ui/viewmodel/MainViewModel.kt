package com.fraudshield.ui.viewmodel

import android.app.Application
import android.content.Context
import android.provider.Telephony
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fraudshield.FraudShieldApp
import com.fraudshield.data.db.RiskLevel
import com.fraudshield.data.db.SmsResult
import com.fraudshield.data.repository.SmsRepository
import com.fraudshield.detection.CloudAIAnalyzer
import com.fraudshield.detection.FraudDetectionEngine
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class DashboardStats(
    val total: Int = 0,
    val dangerous: Int = 0,
    val suspicious: Int = 0,
    val safe: Int = 0,
    val unreadAlerts: Int = 0,
    val avgRiskScore: Double = 0.0
)

data class LinkScanResult(
    val url: String,
    val riskScore: Int,
    val reasons: List<String>,
    val recommendation: String
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repo: SmsRepository = (application as FraudShieldApp).repository
    private val prefs get() = getApplication<Application>()
        .getSharedPreferences("fraudshield_prefs", Context.MODE_PRIVATE)

    // ── Data flows ────────────────────────────────────────────────────────────

    val allResults: StateFlow<List<SmsResult>> = repo.getAllResults()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val alerts: StateFlow<List<SmsResult>> = repo.getAlerts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentResults: StateFlow<List<SmsResult>> = repo.getRecentResults()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dashboardStats: StateFlow<DashboardStats> = combine(
        repo.getTotalCount(),
        repo.getDangerousCount(),
        repo.getSuspiciousCount(),
        repo.getSafeCount(),
        repo.getUnreadAlertCount(),
        repo.getAverageRiskScore()
    ) { values ->
        DashboardStats(
            total = values[0] as Int,
            dangerous = values[1] as Int,
            suspicious = values[2] as Int,
            safe = values[3] as Int,
            unreadAlerts = values[4] as Int,
            avgRiskScore = (values[5] as? Double) ?: 0.0
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardStats())

    // ── Link scanner ──────────────────────────────────────────────────────────

    private val _linkScanResult = MutableStateFlow<LinkScanResult?>(null)
    val linkScanResult: StateFlow<LinkScanResult?> = _linkScanResult

    private val _isLinkScanning = MutableStateFlow(false)
    val isLinkScanning: StateFlow<Boolean> = _isLinkScanning

    // ── Inbox scan ────────────────────────────────────────────────────────────

    private val _isScanningInbox = MutableStateFlow(false)
    val isScanningInbox: StateFlow<Boolean> = _isScanningInbox

    private val _inboxScanProgress = MutableStateFlow(0)
    val inboxScanProgress: StateFlow<Int> = _inboxScanProgress

    // ── Actions ───────────────────────────────────────────────────────────────

    fun markAsRead(id: Long) = viewModelScope.launch { repo.markAsRead(id) }
    fun markAllAsRead() = viewModelScope.launch { repo.markAllAsRead() }
    fun deleteResult(result: SmsResult) = viewModelScope.launch { repo.delete(result) }
    fun deleteAll() = viewModelScope.launch { repo.deleteAll() }

    fun scanUrl(url: String) {
        viewModelScope.launch {
            _isLinkScanning.value = true
            _linkScanResult.value = null
            try {
                val engine = FraudDetectionEngine(getApplication())
                val result = engine.analyze(
                    FraudDetectionEngine.AnalysisInput(sender = "unknown", message = "Check: $url")
                )
                _linkScanResult.value = LinkScanResult(
                    url = url,
                    riskScore = result.riskScore,
                    reasons = result.reasons,
                    recommendation = result.recommendation
                )
            } finally {
                _isLinkScanning.value = false
            }
        }
    }

    fun clearLinkScan() { _linkScanResult.value = null }

    fun scanExistingInbox() {
        if (_isScanningInbox.value) return
        viewModelScope.launch {
            _isScanningInbox.value = true
            _inboxScanProgress.value = 0
            try {
                val context: Context = getApplication()
                val engine = FraudDetectionEngine(context)
                val cursor = context.contentResolver.query(
                    Telephony.Sms.Inbox.CONTENT_URI,
                    arrayOf(Telephony.Sms._ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE),
                    null, null,
                    "${Telephony.Sms.DATE} DESC LIMIT 200"
                ) ?: return@launch

                val total = cursor.count
                var processed = 0
                cursor.use {
                    while (it.moveToNext()) {
                        val address = it.getString(1) ?: "Unknown"
                        val body = it.getString(2) ?: ""
                        val date = it.getLong(3)
                        if (body.isBlank()) continue

                        val result = engine.analyze(
                            FraudDetectionEngine.AnalysisInput(sender = address, message = body)
                        )
                        repo.insert(
                            SmsResult(
                                sender = address,
                                senderDisplayName = if (result.isTrustedSender)
                                    com.fraudshield.detection.TrustedSenders.getTrustLabel(address) ?: address
                                else address,
                                messageBody = body,
                                riskScore = result.riskScore,
                                riskLevel = RiskLevel.fromScore(result.riskScore),
                                detectionReasons = result.reasons.joinToString(" | "),
                                recommendation = result.recommendation,
                                isTrustedSender = result.isTrustedSender,
                                timestamp = date,
                                extractedUrls = result.extractedUrls.joinToString(",")
                            )
                        )
                        processed++
                        _inboxScanProgress.value = if (total > 0) (processed * 100 / total) else 100
                    }
                }
            } finally {
                _isScanningInbox.value = false
                _inboxScanProgress.value = 100
            }
        }
    }

    // ── AI preferences ────────────────────────────────────────────────────────

    fun getSelectedAIProvider(): CloudAIAnalyzer.Provider? {
        val name = prefs.getString("ai_provider", null) ?: return null
        return runCatching { CloudAIAnalyzer.Provider.valueOf(name) }.getOrNull()
    }

    fun setSelectedAIProvider(provider: CloudAIAnalyzer.Provider?) {
        prefs.edit().apply {
            if (provider == null) remove("ai_provider")
            else putString("ai_provider", provider.name)
        }.apply()
    }

    fun getAIKey(provider: CloudAIAnalyzer.Provider): String =
        prefs.getString("ai_key_${provider.name}", "") ?: ""

    fun saveAIKey(provider: CloudAIAnalyzer.Provider, key: String) {
        prefs.edit().putString("ai_key_${provider.name}", key.trim()).apply()
    }

    // Legacy getters — kept for backwards compatibility with SmsReceiver
    @Deprecated("Use getAIKey(provider) instead")
    fun getGeminiApiKey(): String = getAIKey(CloudAIAnalyzer.Provider.GEMINI)

    // ── Monitoring ────────────────────────────────────────────────────────────

    fun getMonitoringEnabled(): Boolean = prefs.getBoolean("monitoring_enabled", true)
    fun setMonitoringEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("monitoring_enabled", enabled).apply()
    }
}
