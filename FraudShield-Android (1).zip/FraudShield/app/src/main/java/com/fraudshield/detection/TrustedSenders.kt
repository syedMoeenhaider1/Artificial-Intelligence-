package com.fraudshield.detection

object TrustedSenders {

    // Exact and prefix matches for Pakistani banks, telecoms, govt, and universities
    private val TRUSTED_EXACT = setOf(
        // Telecom operators
        "jazz", "zong", "telenor", "ufone", "warid",
        // Mobile money / fintech
        "jazzcash", "easypaisa", "nayapay", "sadapay",
        // Banks
        "hbl", "ubl", "meezan", "meezanbank", "allied", "alliedbank",
        "habib", "mcb", "mcbbank", "bankislami", "askari", "askaribank",
        "bop", "bankofpunjab", "nbp", "nationalbank", "scb", "standardchartered",
        "faysal", "faysalbank", "silkbank", "dubai", "dibpak", "alfalah", "bankAlfalah",
        "soneri", "samba", "js", "jsbank", "summit", "unitedbank",
        // Government
        "fbr", "nadra", "pta", "secp", "sbp", "1link", "raast",
        // E-commerce / well-known
        "daraz", "foodpanda", "careem", "bykea",
        // Universities
        "aiou", "vu", "nust", "lums", "iba", "qau", "pu", "uet",
        "comsats", "fast", "numl", "bahria", "superior", "paf-iast"
    )

    // Partial / prefix matching — sender IDs often look like "HBL-ALERTS", "JAZZ-PKG"
    private val TRUSTED_PREFIXES = listOf(
        "hbl", "ubl", "jazz", "zong", "telenor", "ufone",
        "jazzcash", "easypaisa", "nayapay", "sadapay",
        "meezan", "allied", "mcb", "nbp", "bop", "askari",
        "faysal", "alfalah", "bankislami", "scb", "silkbank",
        "fbr", "nadra", "pta", "sbp", "raast", "1link",
        "daraz", "careem", "foodpanda"
    )

    /**
     * Returns true if sender is from a known trusted institution.
     * Alphanumeric sender IDs (like "JAZZCASH", "HBL-ALERTS") are checked here.
     * Numeric phone numbers are NOT trusted by default.
     */
    fun isTrusted(sender: String): Boolean {
        val normalized = sender.lowercase().trim()

        // Numeric phone numbers (e.g. +923001234567) are never auto-trusted
        if (normalized.replace("+", "").replace("-", "").all { it.isDigit() }) {
            return false
        }

        // Exact match
        if (normalized in TRUSTED_EXACT) return true

        // Prefix match
        return TRUSTED_PREFIXES.any { prefix ->
            normalized.startsWith(prefix)
        }
    }

    /**
     * Returns match label for UI display, or null if not trusted.
     */
    fun getTrustLabel(sender: String): String? {
        val normalized = sender.lowercase().trim()
        if (!isTrusted(sender)) return null
        return when {
            normalized.startsWith("jazzcash") -> "JazzCash"
            normalized.startsWith("easypaisa") -> "Easypaisa"
            normalized.startsWith("jazz") -> "Jazz"
            normalized.startsWith("zong") -> "Zong"
            normalized.startsWith("telenor") -> "Telenor"
            normalized.startsWith("ufone") -> "Ufone"
            normalized.startsWith("hbl") -> "HBL"
            normalized.startsWith("ubl") -> "UBL"
            normalized.startsWith("meezan") -> "Meezan Bank"
            normalized.startsWith("allied") -> "Allied Bank"
            normalized.startsWith("mcb") -> "MCB Bank"
            normalized.startsWith("nbp") -> "National Bank"
            normalized.startsWith("fbr") -> "FBR (Govt)"
            normalized.startsWith("nadra") -> "NADRA (Govt)"
            normalized.startsWith("pta") -> "PTA (Govt)"
            normalized.startsWith("sbp") -> "State Bank"
            normalized.startsWith("daraz") -> "Daraz"
            normalized.startsWith("nayapay") -> "NayaPay"
            normalized.startsWith("sadapay") -> "SadaPay"
            normalized.startsWith("1link") || normalized.startsWith("raast") -> "1Link/Raast"
            else -> "Verified Sender"
        }
    }
}
