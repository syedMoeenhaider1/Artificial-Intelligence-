package com.fraudshield.detection

object FraudPatterns {

    data class Pattern(val regex: Regex, val score: Int, val reason: String)

    // --- Lottery & Prize Scams ---
    val LOTTERY_PATTERNS = listOf(
        Pattern(Regex("(?i)\\b(won|winner|winning|congratulations|you.?have.?won)\\b"), 35, "Lottery/prize claim language"),
        Pattern(Regex("(?i)\\b(lucky.?(draw|winner)|prize.?money|prize.?claim)\\b"), 40, "Lucky draw / prize claim"),
        Pattern(Regex("(?i)\\b(bumper.?prize|mega.?prize|grand.?prize)\\b"), 40, "Bumper prize scam"),
        Pattern(Regex("(?i)\\bclaim.?your.?(prize|reward|gift|voucher)\\b"), 35, "Claim prize instruction"),
        Pattern(Regex("(?i)\\bselected.?as.?(a.?)?winner\\b"), 40, "Selected as winner claim"),
        Pattern(Regex("(?i)\\b(pkr|rs|rupees?).{0,15}(lakh|lac|crore|million|billion)\\b"), 30, "Large amount claim")
    )

    // --- Fake Investment Offers ---
    val INVESTMENT_PATTERNS = listOf(
        Pattern(Regex("(?i)\\b(double|triple|10x|100%).{0,10}(profit|return|investment|money)\\b"), 40, "Unrealistic investment returns"),
        Pattern(Regex("(?i)\\b(guaranteed.?profit|guaranteed.?return|risk.?free.?invest)\\b"), 45, "Guaranteed profit scam"),
        Pattern(Regex("(?i)\\b(forex|crypto|bitcoin|binance).{0,15}(profit|earn|invest|trade)\\b"), 30, "Crypto/forex investment pitch"),
        Pattern(Regex("(?i)\\b(trading.?group|invest.?now|join.?scheme)\\b"), 25, "Investment scheme invitation"),
        Pattern(Regex("(?i)\\b(ponzi|mlm|multi.?level|referral.?earn)\\b"), 45, "MLM/Ponzi scheme keywords")
    )

    // --- Phishing & Account Compromise ---
    val PHISHING_PATTERNS = listOf(
        Pattern(Regex("(?i)\\b(verify.?your.?account|account.?suspend|account.?block)\\b"), 35, "Account suspension threat"),
        Pattern(Regex("(?i)\\b(click.?here|tap.?here|open.?link).{0,20}(verify|confirm|update)\\b"), 30, "Phishing CTA with link"),
        Pattern(Regex("(?i)\\b(login.?credentials?|username.?password|enter.?pin|share.?otp)\\b"), 45, "Credential harvesting attempt"),
        Pattern(Regex("(?i)\\b(bank.?account.?detail|card.?detail|cnic.?number|send.?cnic)\\b"), 50, "Requesting sensitive personal info"),
        Pattern(Regex("(?i)\\b(update.?kyc|kyc.?expired|complete.?kyc)\\b"), 35, "Fake KYC update request"),
        Pattern(Regex("(?i)\\bnever.?share.?(your.?)?otp\\b"), -5, "Legitimate OTP warning (negative signal)")
    )

    // --- OTP Context (suspicious if combined with other red flags) ---
    val OTP_PATTERNS = listOf(
        Pattern(Regex("(?i)\\b(otp|one.?time.?(pin|password|code)|verification.?code)\\b"), 5, "OTP message"),
        Pattern(Regex("(?i)\\bshare.?this.?(otp|code|pin)\\b"), 40, "Asking to share OTP"),
        Pattern(Regex("(?i)\\b(otp|code).{0,20}(share|send|forward|give)\\b"), 40, "Requesting OTP sharing")
    )

    // --- Urgency & Pressure ---
    val URGENCY_PATTERNS = listOf(
        Pattern(Regex("(?i)\\b(urgent|immediately|right.?now|expires?.?in|last.?chance|act.?now)\\b"), 15, "Urgency/pressure language"),
        Pattern(Regex("(?i)\\b(limited.?time|offer.?ends|today.?only|24.?hours?)\\b"), 10, "Time-pressure tactic"),
        Pattern(Regex("(?i)\\bor.?your.?(account|number|service).?will.?be.?(block|suspend|terminat)\\b"), 30, "Threat of account blocking")
    )

    // --- Money Requests ---
    val MONEY_PATTERNS = listOf(
        Pattern(Regex("(?i)\\b(send.?money|transfer.?funds?|deposit.?(now|asap|today))\\b"), 30, "Money transfer request"),
        Pattern(Regex("(?i)\\b(mobile.?account|easyload|jazz.?cash|paisa).{0,10}(number|send|transfer)\\b"), 15, "Mobile money transfer request"),
        Pattern(Regex("(?i)\\bfees?.{0,15}(paid?|send|deposit|pay).{0,15}(prize|claim|release|gift)\\b"), 50, "Advance fee fraud")
    )

    // --- Suspicious Links ---
    val URL_SHORTENERS = setOf(
        "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly",
        "is.gd", "buff.ly", "adf.ly", "j.mp", "short.link",
        "rb.gy", "cutt.ly", "shorturl.at", "tiny.cc", "v.gd",
        "clck.ru", "1url.com", "hyperurl.co", "urlzs.com", "qr.ae"
    )

    val URL_REGEX = Regex("""https?://[^\s\]>)'"]+|www\.[^\s\]>)'"]+""")

    // --- Job Scams ---
    val JOB_SCAM_PATTERNS = listOf(
        Pattern(Regex("(?i)\\b(work.?from.?home|earn.?(from|at).?home|part.?time.?earn)\\b"), 25, "Work-from-home scam"),
        Pattern(Regex("(?i)\\b(typing.?job|data.?entry.?earn|copy.?paste.?job)\\b"), 30, "Fake online job offer"),
        Pattern(Regex("(?i)\\b(no.?experience.?required|earn.?\\d+.?per.?day)\\b"), 20, "Unrealistic earning claim")
    )

    // --- Suspicious sender signals ---
    val GENERIC_SUSPICIOUS = listOf(
        Pattern(Regex("(?i)\\b(free.?sim|sim.?blocked|port.?your.?number)\\b"), 20, "SIM-related scam"),
        Pattern(Regex("(?i)\\b(hack|hacked|your.?account.?compromised)\\b"), 35, "Account compromise claim")
    )

    fun extractUrls(message: String): List<String> {
        return URL_REGEX.findAll(message).map { it.value }.toList()
    }

    fun containsShortenerUrl(urls: List<String>): Boolean {
        return urls.any { url ->
            URL_SHORTENERS.any { shortener -> url.contains(shortener, ignoreCase = true) }
        }
    }
}
