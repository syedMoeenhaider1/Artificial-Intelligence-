package com.fraudshield.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fraudshield.data.db.RiskLevel
import com.fraudshield.data.db.SmsResult
import com.fraudshield.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SmsResultCard(
    result: SmsResult,
    onDelete: (() -> Unit)? = null,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    val borderColor = riskColor(result.riskLevel)
    val dateFormat = remember { SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize()
            .combinedClickable(
                onClick = {
                    if (onClick != null) onClick() else expanded = !expanded
                },
                onLongClick = { onDelete?.invoke() }
            ),
        colors = CardDefaults.cardColors(containerColor = Surface),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, borderColor.copy(alpha = 0.35f))
    ) {
        Column(Modifier.padding(16.dp)) {
            // Header row
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Sender icon
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(borderColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = riskEmoji(result.riskLevel),
                        fontSize = 18.sp,
                        color = borderColor
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        text = result.senderDisplayName,
                        color = OnSurface,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = dateFormat.format(Date(result.timestamp)),
                        color = OnSurfaceVariant,
                        fontSize = 12.sp
                    )
                }
                Spacer(Modifier.width(8.dp))
                RiskBadge(level = result.riskLevel, score = result.riskScore)
            }

            Spacer(Modifier.height(12.dp))

            // Message preview
            Text(
                text = result.messageBody,
                color = OnSurfaceVariant,
                fontSize = 13.sp,
                maxLines = if (expanded) Int.MAX_VALUE else 2,
                overflow = if (expanded) TextOverflow.Visible else TextOverflow.Ellipsis,
                lineHeight = 19.sp
            )

            // Expanded details
            if (expanded) {
                Spacer(Modifier.height(12.dp))
                HorizontalDivider(color = Divider)
                Spacer(Modifier.height(12.dp))

                // Detection reasons
                if (result.detectionReasons.isNotBlank()) {
                    Text(
                        text = "Detection Reasons",
                        color = OnSurfaceVariant,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    result.detectionReasons.split(" | ").forEach { reason ->
                        if (reason.isNotBlank()) {
                            Row(
                                verticalAlignment = Alignment.Top,
                                modifier = Modifier.padding(bottom = 3.dp)
                            ) {
                                Text("• ", color = borderColor, fontSize = 13.sp)
                                Text(reason, color = OnSurface, fontSize = 13.sp, lineHeight = 18.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }

                // Recommendation
                if (result.recommendation.isNotBlank()) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(borderColor.copy(alpha = 0.1f))
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.Top) {
                            Icon(
                                Icons.Default.Info,
                                contentDescription = null,
                                tint = borderColor,
                                modifier = Modifier.size(16.dp).padding(top = 1.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                result.recommendation,
                                color = OnSurface,
                                fontSize = 13.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }

                // Gemini verdict
                if (!result.geminiVerdict.isNullOrBlank()) {
                    Text(
                        text = "AI Analysis",
                        color = OnSurfaceVariant,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = result.geminiVerdict,
                        color = Teal80,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                    Spacer(Modifier.height(8.dp))
                }

                // URLs
                if (result.extractedUrls.isNotBlank()) {
                    Text(
                        text = "Links Found",
                        color = OnSurfaceVariant,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(Modifier.height(4.dp))
                    result.extractedUrls.split(",").filter { it.isNotBlank() }.forEach { url ->
                        Text(
                            text = url,
                            color = WarningYellow,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                }

                // Delete action
                if (onDelete != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = onDelete,
                            colors = ButtonDefaults.textButtonColors(contentColor = DangerRed)
                        ) {
                            Icon(Icons.Default.Delete, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Delete", fontSize = 13.sp)
                        }
                    }
                }
            } else {
                // Show expand hint
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = "Tap to expand",
                        color = OnSurfaceVariant,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}
