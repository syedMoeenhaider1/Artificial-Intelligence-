-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.room.* <methods>;
}
-keep class com.fraudshield.data.db.** { *; }
-keep class com.fraudshield.detection.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
