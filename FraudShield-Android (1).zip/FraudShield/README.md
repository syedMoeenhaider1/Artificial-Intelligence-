# FraudShield — Native Android SMS Fraud Detector

A production-ready native Android application (Kotlin + Jetpack Compose) that automatically detects SMS fraud in real time using a hybrid scoring engine tuned for Pakistan's telecom and banking ecosystem.

---

## How to Build in Android Studio

### Prerequisites
- Android Studio Iguana (2023.2.1) or newer
- JDK 17
- Android SDK 34

### Steps

1. **Open the project**
   - Launch Android Studio → `File → Open` → select the `FraudShield/` folder

2. **Sync Gradle**
   - Android Studio will prompt to sync. Click **Sync Now**.
   - On first sync it downloads Gradle 8.6 and all dependencies (~300 MB).

3. **Add the Gradle wrapper JAR** *(one-time only)*
   - Android Studio auto-generates this. If it's missing, run in Terminal:
     ```
     gradle wrapper --gradle-version 8.6
     ```

4. **Build & Run**
   - Connect a real Android device (Android 8.0+, API 26+)
   - Click ▶ **Run** or press `Shift+F10`
   - Grant permissions when prompted on device

5. **Release APK**
   ```
   Build → Generate Signed Bundle/APK → APK
   ```

---

## Architecture

```
com.fraudshield/
├── FraudShieldApp.kt          — Application class, DB + repo init, notification channels
├── MainActivity.kt             — Entry point, permission requests, service start
│
├── data/
│   ├── db/
│   │   ├── AppDatabase.kt     — Room database (v1, SQLite)
│   │   ├── SmsResult.kt       — Entity: scan result with risk score + reasons
│   │   └── SmsResultDao.kt    — DAO: queries, flows, aggregates
│   └── repository/
│       └── SmsRepository.kt   — Single source of truth for UI
│
├── detection/
│   ├── FraudDetectionEngine.kt — PRIMARY decision engine (pattern scoring)
│   ├── TrustedSenders.kt       — Whitelist: JazzCash, Easypaisa, HBL, UBL, etc.
│   ├── FraudPatterns.kt        — Regex pattern groups with per-match scores
│   ├── GeminiAnalyzer.kt       — SECONDARY AI signal (optional, needs API key)
│   └── DetectionResult.kt      — Result model
│
├── receiver/
│   ├── SmsReceiver.kt          — BroadcastReceiver (primary SMS interception)
│   └── BootReceiver.kt         — Restarts service after device reboot
│
├── service/
│   └── SmsMonitorService.kt    — Foreground service + ContentObserver (fallback)
│
├── notification/
│   └── NotificationHelper.kt   — Creates fraud alert and monitor notifications
│
└── ui/
    ├── FraudShieldApp.kt        — Root Compose scaffold + bottom navigation
    ├── theme/                   — Dark theme (teal accent, dark bg)
    ├── navigation/              — Screen definitions
    ├── viewmodel/               — MainViewModel (MVVM, StateFlow)
    ├── components/              — RiskBadge, SmsResultCard, RiskScoreCircle
    └── screens/
        ├── DashboardScreen.kt   — Stats overview + recent scans + inbox scan
        ├── HistoryScreen.kt     — Filterable full scan history
        ├── AlertsScreen.kt      — Suspicious + dangerous alerts
        ├── LinkScannerScreen.kt — Manual URL risk check
        └── SettingsScreen.kt    — Monitoring toggle + Gemini API key
```

---

## How Detection Works

### 1. Trusted Sender Whitelist (first check)
Sender IDs like `JAZZCASH`, `HBL-ALERTS`, `TELENOR-PKG` are matched against a whitelist.
Trusted senders receive a **−30 base score deduction** and are never auto-flagged as fraud.

### 2. Hybrid Pattern Scoring Engine
Six pattern groups each contribute to the risk score:

| Group | Max Score | Examples |
|---|---|---|
| Lottery / Prize Scams | +40 | "You have won", "Lucky draw winner" |
| Fake Investment | +45 | "Guaranteed profit", "Double your money" |
| Phishing / Credential | +50 | "Share OTP", "Send CNIC", "Verify account" |
| Urgency / Pressure | +30 | "Urgent", "Expires in 24 hours", "Act now" |
| Money Requests | +50 | "Send money", "Advance fee", "Deposit now" |
| Job Scams | +30 | "Work from home", "Earn PKR 5000/day" |

### 3. URL Analysis
- **URL shorteners** (bit.ly, tinyurl, etc.) → **+30**
- **Suspicious/misspelled domains** → **+40**
- **Contact lookup** — known contacts get **−10**

### 4. Risk Levels
| Score | Level | Color |
|---|---|---|
| 0–30 | Safe | 🟢 Green |
| 31–60 | Suspicious | 🟡 Yellow |
| 61–100 | Dangerous | 🔴 Red |

### 5. Gemini AI (Secondary)
Optional. Set your API key in Settings. Gemini provides a supporting verdict but **never overrides** the engine's score.

---

## Permissions

| Permission | Why |
|---|---|
| `RECEIVE_SMS` | Intercept incoming SMS via BroadcastReceiver |
| `READ_SMS` | Scan existing inbox on demand |
| `READ_CONTACTS` | Identify known senders (reduces false positives) |
| `INTERNET` | Gemini AI secondary analysis |
| `POST_NOTIFICATIONS` | Alert notifications |
| `FOREGROUND_SERVICE` | Background SMS monitoring service |
| `RECEIVE_BOOT_COMPLETED` | Restart monitoring after device reboot |

---

## Screens

- **Dashboard** — Live stats (total / dangerous / suspicious / safe), recent scans, inbox scan button
- **History** — Full scan log with filter by risk level (All / Dangerous / Suspicious / Safe)
- **Alerts** — Only dangerous and suspicious messages, unread badge on tab
- **Link Scanner** — Paste any URL and check its risk score instantly
- **Settings** — Toggle real-time monitoring, configure Gemini API key, view trusted senders

---

## Getting a Gemini API Key (Free)

1. Visit https://aistudio.google.com/apikey
2. Sign in with Google
3. Create a new key (free tier supports ~1500 requests/day)
4. Open FraudShield → Settings → paste key → Save

The app works fully without a Gemini key. AI analysis is bonus context.

---

## Reporting Fraud

- **PTA Helpline**: 0800-55055
- **Online**: https://pta.gov.pk
- **FIA Cybercrime**: https://complaint.fia.gov.pk
